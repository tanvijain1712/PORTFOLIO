package com.example.calculatorapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.calculatorapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var firstNum = 0.0
    private var operator = ""
    private var isNewOp = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Number Listeners
        val buttons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9, binding.btn00
        )

        buttons.forEach { btn ->
            btn.setOnClickListener { 
                if (isNewOp) {
                    binding.tvResult.text = btn.text
                    isNewOp = false
                } else {
                    binding.tvResult.append(btn.text)
                }
            }
        }

        // Action Listeners
        binding.btnAC.setOnClickListener { 
            binding.tvResult.text = "0"
            binding.tvExpression.text = ""
            firstNum = 0.0
            operator = ""
            isNewOp = true
        }

        binding.btnDel.setOnClickListener {
            val str = binding.tvResult.text.toString()
            if (str.isNotEmpty() && str != "0") {
                val newStr = str.dropLast(1)
                binding.tvResult.text = if (newStr.isEmpty()) "0" else newStr
                if (newStr.isEmpty()) isNewOp = true
            }
        }

        binding.btnPlus.setOnClickListener { prepareOperation("+") }
        binding.btnMinus.setOnClickListener { prepareOperation("-") }
        binding.btnMult.setOnClickListener { prepareOperation("×") }
        binding.btnDiv.setOnClickListener { prepareOperation("÷") }
        
        binding.btnPerc.setOnClickListener {
            val num = binding.tvResult.text.toString().toDoubleOrNull() ?: 0.0
            val res = num / 100
            binding.tvResult.text = formatResult(res)
            isNewOp = true
        }

        binding.btnDot.setOnClickListener { 
            if (isNewOp) {
                binding.tvResult.text = "0."
                isNewOp = false
            } else if (!binding.tvResult.text.contains(".")) {
                binding.tvResult.append(".")
            }
        }

        binding.btnEqual.setOnClickListener { calculate() }
        
        // Initial state
        binding.tvResult.text = "0"
    }

    private fun prepareOperation(op: String) {
        val str = binding.tvResult.text.toString()
        if (str.isNotEmpty() && str != "Error") {
            if (!isNewOp) {
                firstNum = str.toDoubleOrNull() ?: 0.0
            }
            operator = op
            binding.tvExpression.text = "${formatResult(firstNum)} $operator"
            isNewOp = true
        }
    }

    private fun calculate() {
        val str = binding.tvResult.text.toString()
        if (str.isNotEmpty() && operator.isNotEmpty()) {
            val secondNum = str.toDoubleOrNull() ?: 0.0
            val result = when (operator) {
                "+" -> firstNum + secondNum
                "-" -> firstNum - secondNum
                "×" -> firstNum * secondNum
                "÷" -> if (secondNum != 0.0) firstNum / secondNum else Double.NaN
                else -> secondNum
            }
            
            binding.tvExpression.text = "${formatResult(firstNum)} $operator ${formatResult(secondNum)} ="
            
            if (result.isNaN()) {
                binding.tvResult.text = "Error"
            } else {
                binding.tvResult.text = formatResult(result)
            }
            
            operator = ""
            isNewOp = true
        }
    }

    private fun formatResult(num: Double): String {
        return if (num == num.toLong().toDouble()) {
            num.toLong().toString()
        } else {
            num.toString()
        }
    }
}